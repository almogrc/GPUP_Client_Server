package engine.dto;

public interface Dto {
    public String toString();


}
