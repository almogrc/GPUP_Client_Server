package component.api;

public interface HttpStatusUpdate {
    void updateHttpLine(String line);
}
