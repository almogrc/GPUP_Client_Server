package component.api;

public interface ChatCommands extends HttpStatusUpdate {
    void logout();
}
